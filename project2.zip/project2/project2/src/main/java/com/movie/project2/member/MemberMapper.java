package com.movie.project2.member;

import java.util.List;

public interface MemberMapper {
	public abstract int regMember(Member m);

	public abstract List<Member> getAllMember();

	public abstract int login(Member m);

}
