package com.movie.project2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.movie.project2.dao.BoardDAO;
import com.movie.project2.dao.Freeboard;

import jakarta.servlet.http.HttpServletRequest;

@SpringBootApplication
public class Project2Application {

	@Autowired
	private BoardDAO bDAO;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(HttpServletRequest req) {
		req.setAttribute("contentPage", "mainphoto.jsp");
		req.setAttribute("topmenu", "maintop.jsp");
		return "main";
	}

	@RequestMapping(value = "/main", method = RequestMethod.GET)
	public String main(HttpServletRequest req) {
		req.setAttribute("contentPage", "mainphoto.jsp");
		req.setAttribute("topmenu", "maintop.jsp");
		return "main";
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login(HttpServletRequest req) {
		req.setAttribute("contentPage", "login.jsp");
		req.setAttribute("topmenu", "maintop.jsp");
		return "main";
	}

	@RequestMapping(value = "/signup", method = RequestMethod.GET)
	public String signup(HttpServletRequest req) {
		req.setAttribute("contentPage", "signup.jsp");
		req.setAttribute("topmenu", "maintop.jsp");
		return "main";
	}

	@RequestMapping(value = "/Information", method = RequestMethod.GET)
	public String freeboard(HttpServletRequest req) {
		req.setAttribute("contentPage", "Information.jsp");
		req.setAttribute("topmenu", "maintop.jsp");
		return "main";
	}

	@RequestMapping(value = "/2", method = RequestMethod.GET)
	public String noticeboard(HttpServletRequest req) {
		req.setAttribute("contentPage", "2.jsp");
		req.setAttribute("topmenu", "maintop.jsp");
		return "main";
	}

	@RequestMapping(value = "/4", method = RequestMethod.GET)
	public String freeboard(Freeboard f, HttpServletRequest req) {
		int count = bDAO.getFreeboardCount(f);
		int pageNum = bDAO.getFreeboardTotalPage(f);
		req.setAttribute("count", count);
		req.setAttribute("pageNum", pageNum);
		req.setAttribute("page", 1);
		req.setAttribute("contentPage", "4.jsp");
		req.setAttribute("topmenu", "maintop.jsp");
		return "main";
	}

	@RequestMapping(value = "/Freeboarddetail", method = RequestMethod.GET)
	public String reviewboarddetail(HttpServletRequest req) {
		req.setAttribute("contentPage", "Freeboarddetail.jsp");
		req.setAttribute("topmenu", "maintop.jsp");
		return "main";
	}

	@RequestMapping(value = "/Freeboardwrite", method = RequestMethod.GET)
	public String reviewboardwrite(HttpServletRequest req) {
		req.setAttribute("contentPage", "Freeboardwrite.jsp");
		req.setAttribute("topmenu", "maintop.jsp");
		return "main";
	}

	@RequestMapping(value = "/3", method = RequestMethod.GET)
	public String transferboard(HttpServletRequest req) {
		req.setAttribute("contentPage", "3.jsp");
		req.setAttribute("topmenu", "maintop.jsp");
		return "main";
	}
}