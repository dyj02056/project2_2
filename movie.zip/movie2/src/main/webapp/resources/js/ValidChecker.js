function isEmpty(input){
	return (!input.val());
}
